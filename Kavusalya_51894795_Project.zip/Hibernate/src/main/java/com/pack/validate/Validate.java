package com.pack.validate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.pack.login.Customer;
import com.pack.login.Login;
import com.pack.login.PizzaOrder;

public class Validate {
	@Autowired
	private SessionFactory sessionFactory;
	public boolean validate(Login login)
	{
		boolean isCorrectUser=false;
		Session session=sessionFactory.openSession();
		String hql="from Login where userName=:userName and passWord=:passWord";
		Query query=session.createQuery(hql);
		query.setParameter("userName",login.getUsername());
		query.setParameter("passWord",login.getPassword());
		List list=query.getResultList();
		if(list.size()>0)
			isCorrectUser=true;
		else
			isCorrectUser=false;
		return isCorrectUser;
			
	}
	public int placeOrder(Customer customer,PizzaOrder pizzaOrder)
	{
			 Session session=sessionFactory.openSession();
			 Transaction tx=session.beginTransaction();
			 pizzaOrder.setCustomerOrder(customer);
			  session.save(pizzaOrder);
			  int orderid=pizzaOrder.getOrderId();
			  tx.commit();
			  session.close(); 
			  return orderid;
		  
	}
	/*@Autowired
	private HibernateTemplate ht;
	private void setHt(HibernateTemplate ht)
	{
		this.ht=ht;
	}
	public boolean validate(String userName,String passWord)
	{
		boolean isCorrectUser=false;
		String s="from Login l where l.userName=? and l.passWord=?";
		try
		{
			List users=ht.find(s,userName,passWord);
			if(users!=null && users.size()>0)
				isCorrectUser=true;
		}
		catch(Exception e)
		{
			isCorrectUser=false;
			System.out.println(e);
		}
		return isCorrectUser;
	}*/
}
