package com.pack.service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.login.Customer;
import com.pack.login.PizzaOrder;
import com.pack.login.Toppings;

public class Service {
	Service service=new Service();
	private PizzaOrder pizzaOrder;
	/*public int getToppings(Toppings toppings,HttpServletRequest request,HttpServletResponse response)
	{
		int hm=request.getParameterValues("toppings");
	}*/
	public int placeOrder(Customer customer,PizzaOrder pizzaOrder)
	{
		//int totalPrice=350;
		//totalPrice=350+toppings;
		int i=service.placeOrder(customer, pizzaOrder);
		return i;
	}

}
