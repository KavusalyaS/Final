package com.pack.login;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="PizzaOrder")
public class PizzaOrder {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="orderId")
	int orderId;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="customerId",unique=true)
	int customerId;
	@Column(name="totalPrice")
	int totalPrice;
	Customer customer;
	public PizzaOrder()
	{
		
	}
	public void setOrderId(int orderId)
	{
		this.orderId=orderId;
	}
	public int getOrderId()
	{
		return orderId;
	}
	public void setCustomerId(int customerId)
	{
		this.customerId=customerId;
	}
	public int getCustomerId()
	{
		return customerId;
	}
	public void setTotalPrice(int totalPrice)
	{
		this.totalPrice=totalPrice;
	}
	public int getTotalPrice()
	{
		return totalPrice;
	}
    public void setCustomerOrder(Customer customer)
    {
    	this.customer=customer;
    }
    public Customer getCustomerOrder()
    {
    	return customer;
    }
    
}
