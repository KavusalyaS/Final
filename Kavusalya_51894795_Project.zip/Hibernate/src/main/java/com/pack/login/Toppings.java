package com.pack.login;

import java.util.HashMap;

public class Toppings {
	private static HashMap<Integer,String> toppings=new HashMap<Integer,String>();
	public static HashMap<Integer,String> getToppings()
	{
		toppings.put(30,"Capsicum");
		toppings.put(50,"Mushroom");
		toppings.put(70,"Jalapeno");
		toppings.put(85,"Paneer");
		return toppings;
	}

}
