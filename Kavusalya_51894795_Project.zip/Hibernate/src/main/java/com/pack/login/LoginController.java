package com.pack.login;
import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.validate.Validate;
@Controller

public class LoginController {
	@RequestMapping("/login")
	public String loginUser(Model m)
	{
		//System.out.println("in controller");
		m.addAttribute("userBean", new Login());
		return "login";
		//return "final";
	}
	@Autowired
	private Validate validate;
	
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public String validateUser(@Valid @ModelAttribute("userBean")Login login,BindingResult br,Model m)
	{
		/*boolean isCorrect=validate.validate(login);
		if(isCorrect)
			return "final";
		else
			return "login";*/
		if (br.hasErrors())
		 {

		  return "login";
		 }
else
{
	m.addAttribute("login", login);
	validate.validate(login);
	return "home";
}	  
 }
	@RequestMapping("/toplace")
	public String placeOrder(Model m)
	{
		HashMap h=new HashMap();
		h=Toppings.getToppings();
		m.addAttribute("toppings",h);
		m.addAttribute("customer", new Customer());
		return "placeorder";
	}
	@Autowired
	PizzaOrder pizzaOrder;
	@RequestMapping(value="/saveOrder",method=RequestMethod.POST)
	public String saveOrder(@Valid @RequestParam("customer")Customer customer,BindingResult br,Model m)
	{
		int orderid=validate.placeOrder(customer, pizzaOrder);
		m.addAttribute("orderid",orderid);
		if (br.hasErrors())
		 {

		  return "placeorder";
		 }
else
{
	return "final";
}	  
 }

	
}